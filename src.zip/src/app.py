"""
app.py : Streamlit interface for the Bank Marketing CBR project.

    pip install streamlit
    streamlit run app.py

Prerequisites: preprocessing.py has been run (data/processed exists).
For the "Results" tab and the default parameters, also run experiments.py once (results/ folder).

Tabs
  1. Predict a client : enter a client, see the prediction AND the similar past clients that justify it,
                        then tell the system what really happened -> Revise + Retain, live.
  2. Results          : tables and plot produced by experiments.py (Experiment 1 and 2).
  3. About            : the CBR cycle and how it maps to the app.
"""
import json

import numpy as np
import pandas as pd
import streamlit as st

from cbr import CBR, GROUPS, ROOT, WEIGHT_PRESETS, load_cbr_data, make_weights

RESULTS_DIR = ROOT / "results"
INT_COLS = {"age", "campaign", "pdays", "previous"}
GROUP_TITLES = {"profile": "Client profile", "credit": "Credit", "contact": "Current call",
                "history": "History with the bank", "economy": "Economic context"}

st.set_page_config(page_title="Bank Marketing - Case-Based Reasoning", layout="wide")


# ----------------------------------------------------------------------------
# Loading (cached)
# ----------------------------------------------------------------------------
@st.cache_data
def load_data():
    return load_cbr_data()


@st.cache_resource
def load_base(preset):
    """The initial case base (training clients) with the weights of the chosen preset."""
    data, meta = load_data()
    num, cat = meta["numeric_cols"], meta["categorical_cols"]
    weights = make_weights(num + cat, WEIGHT_PRESETS[preset])
    return CBR(num, cat, weights).fit(data["train"], extra_capacity=5000)


def default_params():
    path = RESULTS_DIR / "best_parameters.json"
    if path.exists():
        with open(path, encoding="utf-8") as f:
            return json.load(f)["cbr"]
    return {"preset": "groups_A", "k": 21, "power": 1, "threshold": 0.15}


def reset_session(preset):
    st.session_state.model = load_base(preset).clone()
    st.session_state.preset = preset
    st.session_state.last = None
    st.session_state.n_added = 0


try:
    data, meta = load_data()
except FileNotFoundError:
    st.error("data/processed not found. Run `python preprocessing.py` first.")
    st.stop()

num_cols, cat_cols = meta["numeric_cols"], meta["categorical_cols"]
best = default_params()

# ----------------------------------------------------------------------------
# Sidebar: CBR parameters
# ----------------------------------------------------------------------------
st.sidebar.header("CBR parameters")
presets = list(WEIGHT_PRESETS)
preset = st.sidebar.selectbox("Variable weights", presets,
                              index=presets.index(best["preset"]) if best["preset"] in presets else 0)
k = st.sidebar.slider("k (similar clients retrieved)", 1, 101, int(best["k"]))
power_options = [1, 2, 5]
power = st.sidebar.selectbox("Similarity power (closer clients count more)", power_options,
                             index=power_options.index(int(best["power"])) if int(best["power"]) in power_options else 0)
threshold = st.sidebar.slider("Decision threshold", 0.0, 1.0, float(round(best["threshold"], 2)), 0.01,
                              help="Predict 'subscribe' if the score is at least this value. "
                                   "Only ~11% of clients subscribe, so it is much lower than 0.5.")

if "model" not in st.session_state or st.session_state.get("preset") != preset:
    reset_session(preset)
if st.sidebar.button("Reset case base"):
    reset_session(preset)

model = st.session_state.model
model.k, model.power, model.threshold = k, power, threshold
st.sidebar.metric("Cases in the case base", model.n)
st.sidebar.caption(f"Clients added in this session: {st.session_state.n_added}")

tab_predict, tab_results, tab_about = st.tabs(["Predict a client", "Results", "About CBR"])


# ----------------------------------------------------------------------------
# Tab 1: predict, explain, revise, retain
# ----------------------------------------------------------------------------
def raw_default(col):
    mn, mx = meta["numeric_min"][col], meta["numeric_max"][col]
    v = float(data["train"][col].median()) * (mx - mn) + mn
    return int(round(v)) if col in INT_COLS or col == "previously_contacted" else v


def numeric_input(col, container):
    mn, mx = meta["numeric_min"][col], meta["numeric_max"][col]
    if col == "previously_contacted":
        return int(container.checkbox("Contacted in a previous campaign", value=bool(raw_default(col)), key=f"in_{col}"))
    if col in INT_COLS:
        return container.number_input(col, min_value=int(mn), max_value=int(mx),
                                      value=int(np.clip(raw_default(col), mn, mx)), step=1, key=f"in_{col}")
    step = float((mx - mn) / 200) or 0.01
    return container.number_input(col, min_value=float(mn), max_value=float(mx),
                                  value=float(np.clip(raw_default(col), mn, mx)), step=step,
                                  format="%.3f", key=f"in_{col}")


def categorical_input(col, container):
    options = sorted(model.cat_maps[col].keys())
    mode = data["train"][col].mode().iloc[0]
    return container.selectbox(col, options, index=options.index(mode), key=f"in_{col}")


with tab_predict:
    st.subheader("1. Describe the client (known before the call)")
    st.caption("The call duration is not asked: it is unknown before the call and was removed from the data.")

    values = {}
    with st.form("client_form"):
        grouped = [(GROUP_TITLES[g], [c for c in cols if c in num_cols + cat_cols]) for g, cols in GROUPS.items()]
        known = {c for _, cols in grouped for c in cols}
        other = [c for c in num_cols + cat_cols if c not in known]
        if other:
            grouped.append(("Other", other))
        for title, cols in grouped:
            if not cols:
                continue
            with st.expander(title, expanded=(title in ("Client profile", "History with the bank"))):
                grid = st.columns(2)
                for i, c in enumerate(cols):
                    box = grid[i % 2]
                    values[c] = numeric_input(c, box) if c in num_cols else categorical_input(c, box)
        submitted = st.form_submit_button("Retrieve similar clients and predict")

    if submitted:
        row = {}
        for c in num_cols:
            mn, mx = meta["numeric_min"][c], meta["numeric_max"][c]
            v = values[c]
            if c == "pdays" and not values.get("previously_contacted", 1):
                v = 0  # same convention as preprocessing.py
            row[c] = float(np.clip((v - mn) / (mx - mn), 0, 1)) if mx > mn else 0.0
        for c in cat_cols:
            row[c] = values[c]
        xn, xc = model.encode(pd.DataFrame([row]))
        idx, sims = model.neighbours(xn[0], xc[0], k)
        score = model.score(idx, sims)
        _, table = model.explain(xn[0], xc[0], k=k, num_min=meta["numeric_min"], num_max=meta["numeric_max"])
        st.session_state.last = {"idx": idx, "sims": sims, "xn": xn[0], "xc": xc[0], "score": score,
                                 "pred": int(score >= model.threshold), "table": table, "answered": False}

    last = st.session_state.last
    if last is not None:
        st.subheader("2. Prediction and explanation")
        c1, c2, c3 = st.columns(3)
        c1.metric("Score (weighted share of subscribers among neighbours)", f"{last['score']:.2f}")
        c2.metric("Decision threshold", f"{model.threshold:.2f}")
        c3.metric("Prediction", "Will subscribe" if last["pred"] else "Will not subscribe")

        table = last["table"]
        n_yes = int((table["outcome"] == "yes").sum())
        st.write(f"Among the **{len(table)} most similar past clients**, **{n_yes}** subscribed "
                 f"and **{len(table) - n_yes}** did not. This is the explanation of the prediction:")
        first = ["rank", "similarity", "outcome", "reliability", "same_categories"]
        st.dataframe(table[first + [c for c in table.columns if c not in first]],
                     hide_index=True)

        st.subheader("3. Revise and retain")
        if last["answered"]:
            st.success("This client has been added to the case base with his real outcome.")
        else:
            real = st.radio("What really happened after the call?", ["Subscribed", "Did not subscribe"],
                            horizontal=True)
            if st.button("Confirm real outcome (Revise + Retain)"):
                y_true = 1 if real == "Subscribed" else 0
                wrong = model.revise(last["idx"], last["pred"], y_true)
                model.retain(last["xn"], last["xc"], y_true)
                last["answered"] = True
                st.session_state.n_added += 1
                if wrong:
                    st.warning("The prediction was wrong: the neighbours that misled us lost reliability "
                               "(REVISE). The client is now in the case base (RETAIN).")
                else:
                    st.success("The prediction was right: the neighbours that voted correctly regain "
                               "reliability (REVISE). The client is now in the case base (RETAIN).")
                st.info(f"The case base now holds {model.n} clients. Predict the same client again to see the effect.")


# ----------------------------------------------------------------------------
# Tab 2: results of experiments.py
# ----------------------------------------------------------------------------
with tab_results:
    exp1, exp2, img = RESULTS_DIR / "experiment1.csv", RESULTS_DIR / "experiment2.csv", RESULTS_DIR / "experiment2.png"
    if not exp1.exists():
        st.info("No results yet. Run `python experiments.py` first.")
    else:
        st.subheader("Experiment 1: CBR vs k-NN (case base frozen, same test clients)")
        st.dataframe(pd.read_csv(exp1, index_col=0))
        st.caption("Main metric: balanced accuracy. The 'always no' row shows why accuracy alone is misleading.")
    if exp2.exists():
        st.subheader("Experiment 2: test clients one by one (predict, then revise + retain)")
        st.dataframe(pd.read_csv(exp2, index_col=0))
    if img.exists():
        st.image(str(img))
    params = RESULTS_DIR / "best_parameters.json"
    if params.exists():
        with st.expander("Parameters chosen on the validation set"):
            st.json(json.load(open(params, encoding="utf-8")))


# ----------------------------------------------------------------------------
# Tab 3: about
# ----------------------------------------------------------------------------
with tab_about:
    st.markdown("""
### The CBR cycle in this app

| Step | What happens | Where you see it |
|---|---|---|
| **Retrieve** | Find the k most similar past clients (weighted similarity) | The table of neighbours |
| **Reuse** | Predict from their outcomes (similarity-weighted vote) | The score and the decision |
| **Revise** | Compare with the real outcome; neighbours that misled us lose reliability | The "Confirm real outcome" button |
| **Retain** | Add the new client, with his real outcome, to the case base | The case counter in the sidebar |

**Why the threshold is low:** only about 11% of clients subscribe, so a threshold of 0.5 would almost always
predict "no". The threshold is tuned on the validation set to maximize the **balanced accuracy**.

**Why there is no call duration:** it is unknown before the call, so using it would be data leakage.

**Weights:** the variables are grouped (profile, credit, call, history, economy) and each group shares a weight,
so the five correlated economic indicators do not count five times.

**RAG vs this app:** here the retrieved cases *are* the answer (their outcomes are reused directly).
In RAG, the retrieved items would be handed to a generator (an LLM) as context.
""")
