"""
cbr.py : a simple Case-Based Reasoning system for the Bank Marketing data.

A CASE   = one past client (problem description) + his real outcome (target: 1 = subscribed).
THE CYCLE (the 4 R's), one method each:
    retrieve : find the k most similar past clients          -> neighbours()
    reuse    : turn their outcomes into a prediction         -> score()
    revise   : once the real outcome is known, check the prediction and correct -> revise()
    retain   : add the new client with his real outcome      -> retain()

Similarity between two clients
    distance = sum_j  w_j * d_j(a_j, b_j)  /  sum_j w_j          (value in [0, 1])
    similarity = 1 - distance
  with d_j = |a - b| for numeric variables (already scaled to [0, 1] by preprocessing.py)
       d_j = 0 if same category, 1 otherwise, for categorical variables.

Prediction (reuse)
    score = weighted share of "subscribed" among the k neighbours, where each neighbour counts
            similarity**power * reliability.
    The client is predicted to subscribe if score >= threshold.
    The threshold is NOT 0.5: only ~11% of clients subscribe, so it is tuned on the validation
    set to maximize the balanced accuracy.

Revise (our simple, explainable rule)
    Every case has a "reliability" (starts at 1). When a prediction is wrong, the neighbours that
    voted for the wrong outcome lose reliability (x decay), so they weigh less next time.
    When a prediction is right, the neighbours that voted correctly regain some (capped at 1).
"""
import copy
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (balanced_accuracy_score, confusion_matrix,
                             roc_auc_score)

try:
    ROOT = Path(__file__).resolve().parent.parent
except NameError:  # notebook
    ROOT = Path.cwd()
PROCESSED_DIR = ROOT / "data" / "processed"


# ----------------------------------------------------------------------------
# Loading data prepared by preprocessing.py
# ----------------------------------------------------------------------------
def load_cbr_data(processed_dir=PROCESSED_DIR):
    processed_dir = Path(processed_dir)
    with open(processed_dir / "metadata.json", encoding="utf-8") as f:
        meta = json.load(f)
    data = {k: pd.read_csv(processed_dir / f"cbr_{k}.csv") for k in ["train", "val", "test"]}
    return data, meta


# ----------------------------------------------------------------------------
# Variable weights: groups of variables share a weight (correlated variables
# such as the 5 economic indicators must not count 5 times).
# These presets are STARTING POINTS justified by the EDA (poutcome, economy and
# contact type were the strongest signals); the best one is chosen on validation.
# ----------------------------------------------------------------------------
GROUPS = {
    "profile": ["age", "job", "marital", "education"],
    "credit": ["default", "housing", "loan"],
    "contact": ["contact", "month", "day_of_week"],
    "history": ["campaign", "pdays", "previous", "poutcome", "previously_contacted"],
    "economy": ["emp.var.rate", "cons.price.idx", "cons.conf.idx", "euribor3m", "nr.employed"],
}

WEIGHT_PRESETS = {
    "equal": None,  # every variable has weight 1
    "groups_A": {"profile": 2.0, "credit": 0.5, "contact": 1.5, "history": 3.0, "economy": 3.0},
    "groups_B": {"profile": 1.5, "credit": 0.5, "contact": 1.0, "history": 3.0, "economy": 4.0},
}


def make_weights(columns, group_weights=None):
    """Weight per variable. A group weight is SHARED among the variables of the group."""
    if group_weights is None:
        return {c: 1.0 for c in columns}
    w, assigned = {}, set()
    for g, cols in GROUPS.items():
        present = [c for c in cols if c in columns]
        for c in present:
            w[c] = group_weights[g] / len(present)
        assigned |= set(present)
    for c in columns:  # variables not in any group (e.g. 'balance' in the older dataset version)
        if c not in assigned:
            w[c] = 0.5
    return w


# ----------------------------------------------------------------------------
# Metrics helpers (also used by baseline_knn.py and experiments.py)
# ----------------------------------------------------------------------------
def best_threshold(y_true, scores, n_grid=300):
    """Threshold on the score that maximizes the balanced accuracy. Returns (threshold, BA)."""
    y_true = np.asarray(y_true)
    scores = np.asarray(scores, dtype=float)
    cands = np.unique(scores)
    if len(cands) > n_grid:
        cands = np.unique(np.quantile(scores, np.linspace(0, 1, n_grid)))
    pos = max(int((y_true == 1).sum()), 1)
    neg = max(int((y_true == 0).sum()), 1)
    best_t, best_ba = 0.5, -1.0
    for t in cands:
        pred = scores >= t
        tpr = (pred & (y_true == 1)).sum() / pos
        tnr = (~pred & (y_true == 0)).sum() / neg
        ba = (tpr + tnr) / 2
        if ba > best_ba:
            best_t, best_ba = float(t), float(ba)
    return best_t, best_ba


def evaluate(y_true, y_pred, score=None):
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    out = {
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "recall_yes": tp / (tp + fn) if tp + fn else 0.0,
        "precision_yes": tp / (tp + fp) if tp + fp else 0.0,
        "accuracy": (tp + tn) / len(y_true),
        "TP": int(tp), "FP": int(fp), "FN": int(fn), "TN": int(tn),
    }
    if score is not None:
        out["roc_auc"] = roc_auc_score(y_true, score)
    return out


def bootstrap_ba(y_true, y_pred, n_boot=300, seed=0):
    """95% confidence interval of the balanced accuracy (resampling the test clients)."""
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        i = rng.integers(0, len(y_true), len(y_true))
        if y_true[i].min() == y_true[i].max():
            continue
        vals.append(balanced_accuracy_score(y_true[i], y_pred[i]))
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


# ----------------------------------------------------------------------------
# The CBR system
# ----------------------------------------------------------------------------
class CBR:
    def __init__(self, numeric_cols, categorical_cols, weights=None, k=15, power=1.0,
                 threshold=0.5, decay=0.9, min_reliability=0.1):
        self.numeric_cols = list(numeric_cols)
        self.categorical_cols = list(categorical_cols)
        allcols = self.numeric_cols + self.categorical_cols
        weights = weights or {c: 1.0 for c in allcols}
        self.weights = weights
        self.w_num = np.array([weights[c] for c in self.numeric_cols], dtype=np.float32)
        self.w_cat = np.array([weights[c] for c in self.categorical_cols], dtype=np.float32)
        self.w_sum = float(self.w_num.sum() + self.w_cat.sum())
        self.k, self.power, self.threshold = k, power, threshold
        self.decay, self.min_reliability = decay, min_reliability
        self.cat_maps = {c: {} for c in self.categorical_cols}
        self.n = 0

    # ----- building the case base -------------------------------------------
    def encode(self, df):
        """DataFrame -> (numeric matrix, categorical integer codes). New categories get new codes."""
        xnum = df[self.numeric_cols].to_numpy(dtype=np.float32)
        xcat = np.empty((len(df), len(self.categorical_cols)), dtype=np.int16)
        for j, c in enumerate(self.categorical_cols):
            m = self.cat_maps[c]
            for v in pd.unique(df[c]):
                if v not in m:
                    m[v] = len(m)
            xcat[:, j] = df[c].map(m).to_numpy()
        return xnum, xcat

    def fit(self, df, extra_capacity=0):
        """Store the training clients as the initial case base (no learning happens here)."""
        xnum, xcat = self.encode(df)
        n = len(df)
        cap = n + extra_capacity
        self.Xnum = np.zeros((cap, len(self.numeric_cols)), dtype=np.float32)
        self.Xcat = np.full((cap, len(self.categorical_cols)), -1, dtype=np.int16)
        self.y = np.zeros(cap, dtype=np.int8)
        self.reliability = np.ones(cap, dtype=np.float32)
        self.Xnum[:n], self.Xcat[:n], self.y[:n] = xnum, xcat, df["target"].to_numpy()
        self.n = n
        return self

    def clone(self):
        return copy.deepcopy(self)

    # ----- 1. RETRIEVE ---------------------------------------------------------
    def neighbours(self, xnum, xcat, k=None):
        """The k most similar cases of ONE client. Returns (case indices, similarities), best first."""
        k = min(k or self.k, self.n)
        n = self.n
        d_num = np.abs(self.Xnum[:n] - xnum) @ self.w_num
        d_cat = (self.Xcat[:n] != xcat).astype(np.float32) @ self.w_cat
        dist = (d_num + d_cat) / self.w_sum
        idx = np.argpartition(dist, k - 1)[:k]
        idx = idx[np.argsort(dist[idx])]
        return idx, 1.0 - dist[idx]

    def batch_neighbours(self, xnum, xcat, k):
        m = len(xnum)
        idx = np.empty((m, k), dtype=np.int32)
        sims = np.empty((m, k), dtype=np.float32)
        for i in range(m):
            idx[i], sims[i] = self.neighbours(xnum[i], xcat[i], k)
        return idx, sims

    # ----- 2. REUSE ------------------------------------------------------------
    def score(self, idx, sims, k=None):
        """Weighted share of 'subscribed' among the neighbours of ONE client (value in [0, 1])."""
        if k is not None:
            idx, sims = idx[:k], sims[:k]
        w = np.maximum(sims, 1e-6) ** self.power * self.reliability[idx]
        return float((w * self.y[idx]).sum() / w.sum())

    def batch_scores(self, idx, sims, k):
        """Same as score() for many clients at once, using only the k best neighbours."""
        i, s = idx[:, :k], sims[:, :k]
        w = np.maximum(s, 1e-6) ** self.power * self.reliability[i]
        return (w * self.y[i]).sum(axis=1) / w.sum(axis=1)

    def predict(self, df, k=None):
        """Scores and 0/1 predictions for a DataFrame (case base unchanged)."""
        k = k or self.k
        xnum, xcat = self.encode(df)
        idx, sims = self.batch_neighbours(xnum, xcat, k)
        scores = self.batch_scores(idx, sims, k)
        return scores, (scores >= self.threshold).astype(int)

    # ----- 3. REVISE -----------------------------------------------------------
    def revise(self, idx, y_pred, y_true):
        """Check the prediction against the real outcome and correct the cases that misled us."""
        voted = self.y[idx]
        if y_pred != y_true:
            bad = idx[voted == y_pred]  # neighbours that pushed toward the wrong outcome
            self.reliability[bad] = np.maximum(self.min_reliability, self.reliability[bad] * self.decay)
            return True
        good = idx[voted == y_true]
        self.reliability[good] = np.minimum(1.0, self.reliability[good] / self.decay)
        return False

    # ----- 4. RETAIN -----------------------------------------------------------
    def retain(self, xnum, xcat, y_true):
        """Add the new client, with his REAL outcome, to the case base."""
        if self.n >= len(self.y):
            extra = max(1000, self.n // 2)
            self.Xnum = np.vstack([self.Xnum, np.zeros((extra, self.Xnum.shape[1]), np.float32)])
            self.Xcat = np.vstack([self.Xcat, np.full((extra, self.Xcat.shape[1]), -1, np.int16)])
            self.y = np.concatenate([self.y, np.zeros(extra, np.int8)])
            self.reliability = np.concatenate([self.reliability, np.ones(extra, np.float32)])
        i = self.n
        self.Xnum[i], self.Xcat[i], self.y[i], self.reliability[i] = xnum, xcat, y_true, 1.0
        self.n += 1

    # ----- Explanation -----------------------------------------------------------
    def explain(self, xnum, xcat, k=None, num_min=None, num_max=None):
        """Score + table of the retrieved clients: this IS the explanation of the prediction."""
        idx, sims = self.neighbours(xnum, xcat, k)
        score = self.score(idx, sims)
        inv = {c: {v: key for key, v in m.items()} for c, m in self.cat_maps.items()}
        rows = []
        for rank, (i, s) in enumerate(zip(idx, sims), 1):
            row = {"rank": rank, "similarity": round(float(s), 3),
                   "outcome": "yes" if self.y[i] else "no",
                   "reliability": round(float(self.reliability[i]), 2)}
            for j, c in enumerate(self.numeric_cols):
                v = float(self.Xnum[i, j])
                if num_min is not None:  # back to original units
                    v = v * (num_max[c] - num_min[c]) + num_min[c]
                row[c] = round(v, 2)
            for j, c in enumerate(self.categorical_cols):
                row[c] = inv[c].get(int(self.Xcat[i, j]), "?")
            row["same_categories"] = int((self.Xcat[i] == xcat).sum())
            rows.append(row)
        return score, pd.DataFrame(rows)


if __name__ == "__main__":
    # Tiny demo: Retrieve + Reuse on the validation set with default settings
    data, meta = load_cbr_data()
    cols = meta["numeric_cols"] + meta["categorical_cols"]
    m = CBR(meta["numeric_cols"], meta["categorical_cols"], make_weights(cols, WEIGHT_PRESETS["groups_A"]), k=21)
    m.fit(data["train"])
    val = data["val"].head(1000)
    s, _ = m.predict(val)
    t, ba = best_threshold(val["target"], s)
    print(f"Quick check on 1000 validation clients: best threshold = {t:.3f}, balanced accuracy = {ba:.3f}")
