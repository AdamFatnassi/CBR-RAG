"""
experiments.py : runs the whole project and saves tables/plots in results/.

    python experiments.py            # full run (a few minutes on the real data)
    python experiments.py --quick    # fast run on subsets, to check that everything works

Steps
  0. Load the prepared data (run preprocessing.py first).
  1. k-NN baseline: tune k and threshold on validation.
  2. CBR: tune weights preset, k, power and threshold on validation.
  3. EXPERIMENT 1 (static): CBR vs k-NN on the SAME test clients, case base frozen
     (tests Retrieve + Reuse only).
  4. EXPERIMENT 2 (online): test clients one by one: predict first, then revise + retain.
     Compared with the same CBR without learning (and with "retain only").
  5. Example of an explained prediction (the retrieved clients).
"""
import argparse
import json
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import balanced_accuracy_score

from src.baseline_knn import load_knn_data, run_knn
from src.cbr import (CBR, ROOT, WEIGHT_PRESETS, best_threshold, bootstrap_ba, evaluate,
                 load_cbr_data, make_weights)

RESULTS_DIR = ROOT / "results"
K_GRID = [5, 11, 21, 41, 81]
POWERS = [1, 5]
SEED = 42


# ----------------------------------------------------------------------------
# CBR tuning (validation set only)
# ----------------------------------------------------------------------------
def build_cbr(train, meta, preset, k, power, threshold, extra_capacity=0):
    num, cat = meta["numeric_cols"], meta["categorical_cols"]
    weights = make_weights(num + cat, WEIGHT_PRESETS[preset])
    model = CBR(num, cat, weights, k=k, power=power, threshold=threshold)
    return model.fit(train, extra_capacity=extra_capacity)


def tune_cbr(train, val, meta):
    kmax = max(K_GRID)
    yv = val["target"].to_numpy()
    rows = []
    for preset in WEIGHT_PRESETS:
        t0 = time.time()
        model = build_cbr(train, meta, preset, k=kmax, power=1, threshold=0.5)
        xn, xc = model.encode(val)
        idx, sims = model.batch_neighbours(xn, xc, kmax)  # neighbours computed once per preset
        for power in POWERS:
            model.power = power
            for k in K_GRID:
                scores = model.batch_scores(idx, sims, k)
                thr, ba = best_threshold(yv, scores)
                rows.append({"preset": preset, "power": power, "k": k,
                             "threshold": thr, "val_balanced_accuracy": ba})
        best_p = max((r for r in rows if r["preset"] == preset), key=lambda r: r["val_balanced_accuracy"])
        print(f"  CBR  weights={preset:9s} best val BA = {best_p['val_balanced_accuracy']:.4f} "
              f"(k={best_p['k']}, power={best_p['power']})  [{time.time() - t0:.0f}s]")
    table = pd.DataFrame(rows)
    best = table.loc[table["val_balanced_accuracy"].idxmax()].to_dict()
    best["k"], best["power"] = int(best["k"]), int(best["power"])
    return best, table


# ----------------------------------------------------------------------------
# Experiment 2: online loop
# ----------------------------------------------------------------------------
def online_run(base, xn, xc, y, revise, retain):
    """Test clients one by one: PREDICT first, then (optionally) revise and retain."""
    m = base.clone()
    scores = np.empty(len(y))
    preds = np.empty(len(y), dtype=int)
    n_wrong = 0
    for i in range(len(y)):
        idx, sims = m.neighbours(xn[i], xc[i], m.k)
        s = m.score(idx, sims)
        p = int(s >= m.threshold)
        scores[i], preds[i] = s, p
        n_wrong += int(p != y[i])
        if revise:
            m.revise(idx, p, y[i])
        if retain:
            m.retain(xn[i], xc[i], y[i])
    return scores, preds, m.n


def rolling_ba(y, pred, window, step):
    xs, vals = [], []
    for end in range(window, len(y) + 1, step):
        sl = slice(end - window, end)
        vals.append(balanced_accuracy_score(y[sl], pred[sl]))
        xs.append(end)
    return np.array(xs), np.array(vals)


# ----------------------------------------------------------------------------
def main(quick=False):
    RESULTS_DIR.mkdir(exist_ok=True)
    rng = np.random.default_rng(SEED)

    print("Loading data ...")
    cbr_data, meta = load_cbr_data()
    knn_data = load_knn_data()
    train, val, test = cbr_data["train"], cbr_data["val"], cbr_data["test"]

    val_idx = test_idx = None
    if quick:
        val_idx = np.sort(rng.choice(len(val), min(1500, len(val)), replace=False))
        test_idx = np.arange(min(1500, len(test)))  # first clients, order kept
        val, test = val.iloc[val_idx].reset_index(drop=True), test.iloc[test_idx].reset_index(drop=True)
        print(f"QUICK MODE: {len(val)} validation and {len(test)} test clients")
    y_test = test["target"].to_numpy()
    print(f"Case base (train): {len(train)} clients | validation: {len(val)} | test: {len(test)}")

    # ---- 1. k-NN baseline ------------------------------------------------------
    print("\n[1/4] k-NN baseline (tuning on validation)")
    knn = run_knn(knn_data, K_GRID, val_idx=val_idx, test_idx=test_idx)
    assert (knn["y_test"] == y_test).all(), "k-NN and CBR views are not aligned"

    # ---- 2. CBR tuning -----------------------------------------------------------
    print("\n[2/4] CBR (tuning weights, k, power, threshold on validation)")
    best, tuning = tune_cbr(train, val, meta)
    tuning.to_csv(RESULTS_DIR / "tuning_cbr.csv", index=False)
    pd.DataFrame(knn["tuning"]).to_csv(RESULTS_DIR / "tuning_knn.csv", index=False)
    with open(RESULTS_DIR / "best_parameters.json", "w", encoding="utf-8") as f:
        json.dump({"cbr": best, "knn": {"k": knn["k"], "threshold": knn["threshold"]}}, f, indent=2)
    print(f"  -> CBR choice: {best['preset']}, k={best['k']}, power={best['power']}, "
          f"threshold={best['threshold']:.3f}")

    # ---- 3. Experiment 1 ---------------------------------------------------------
    print("\n[3/4] EXPERIMENT 1: CBR vs k-NN, case base frozen (same test clients)")
    base = build_cbr(train, meta, best["preset"], best["k"], best["power"], best["threshold"],
                     extra_capacity=len(test))
    xn, xc = base.encode(test)  # also registers any new category before cloning
    idx, sims = base.batch_neighbours(xn, xc, best["k"])
    cbr_scores = base.batch_scores(idx, sims, best["k"])
    cbr_pred = (cbr_scores >= best["threshold"]).astype(int)

    results = {}
    for name, pred, sc in [("CBR (retrieve + reuse)", cbr_pred, cbr_scores),
                           ("k-NN scikit-learn", knn["test_pred"], knn["test_scores"]),
                           ("Always 'no' (reference)", np.zeros_like(y_test), None)]:
        r = evaluate(y_test, pred, sc)
        lo, hi = bootstrap_ba(y_test, pred)
        r["BA 95% CI"] = f"[{lo:.3f}, {hi:.3f}]"
        results[name] = r
    exp1 = pd.DataFrame(results).T
    cols = ["balanced_accuracy", "BA 95% CI", "recall_yes", "precision_yes", "roc_auc", "accuracy",
            "TP", "FP", "FN", "TN"]
    exp1 = exp1[[c for c in cols if c in exp1.columns]]
    exp1.to_csv(RESULTS_DIR / "experiment1.csv")
    print(exp1.to_string(float_format=lambda v: f"{v:.3f}"))

    # ---- 4. Experiment 2 ---------------------------------------------------------
    print("\n[4/4] EXPERIMENT 2: test clients one by one (predict first, then revise + retain)")
    variants = {"CBR without learning": (False, False),
                "CBR retain only": (False, True),
                "CBR revise + retain": (True, True)}
    window = min(1000, max(200, len(test) // 3))
    step = max(100, window // 4)
    fig, ax = plt.subplots(figsize=(9, 4.8))
    rows = []
    half = len(test) // 2
    for name, (rev, ret) in variants.items():
        t0 = time.time()
        sc, pr, n_final = online_run(base, xn, xc, y_test, rev, ret)
        xs, ys = rolling_ba(y_test, pr, window, step)
        ax.plot(xs, ys, marker="o", ms=3, label=name)
        rows.append({"variant": name,
                     "BA all test clients": balanced_accuracy_score(y_test, pr),
                     "BA 2nd half of test": balanced_accuracy_score(y_test[half:], pr[half:]),
                     "case base at the end": n_final})
        print(f"  {name:22s} done [{time.time() - t0:.0f}s]")
    # k-NN (frozen) as a reference curve
    xs, ys = rolling_ba(y_test, knn["test_pred"], window, step)
    ax.plot(xs, ys, ls="--", color="gray", label="k-NN (frozen)")
    rows.append({"variant": "k-NN (frozen)",
                 "BA all test clients": balanced_accuracy_score(y_test, knn["test_pred"]),
                 "BA 2nd half of test": balanced_accuracy_score(y_test[half:], knn["test_pred"][half:]),
                 "case base at the end": len(train)})
    ax.set_xlabel("number of test clients processed")
    ax.set_ylabel(f"balanced accuracy (window of {window} clients)")
    ax.set_title("Experiment 2: quality while the case base evolves")
    ax.legend()
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "experiment2.png", dpi=150)
    exp2 = pd.DataFrame(rows).set_index("variant")
    exp2.to_csv(RESULTS_DIR / "experiment2.csv")
    print(exp2.to_string(float_format=lambda v: f"{v:.3f}"))

    # ---- Explained prediction ----------------------------------------------------
    pick = np.where((cbr_pred == 1) & (y_test == 1))[0]
    i = int(pick[0]) if len(pick) else 0
    score, table = base.explain(xn[i], xc[i], k=min(best["k"], 10),
                                num_min=meta["numeric_min"], num_max=meta["numeric_max"])
    table.to_csv(RESULTS_DIR / "example_explanation.csv", index=False)
    print(f"\nExample: test client #{i}, score = {score:.2f}, real outcome = {'yes' if y_test[i] else 'no'}")
    show = ["rank", "similarity", "outcome", "same_categories", "poutcome", "contact", "job", "age"]
    print(table[[c for c in show if c in table.columns]].to_string(index=False))
    print(f"\nAll results saved in {RESULTS_DIR}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="fast run on subsets")
    main(ap.parse_args().quick)
