"""
baseline_knn.py : the k-NN reference method (scikit-learn).

Uses the k-NN view of the data prepared by preprocessing.py (data/processed/knn_arrays.npz):
standardized numeric variables + one-hot categories. Same train / validation / test clients as the CBR.

For a FAIR comparison, k-NN gets the same treatment as the CBR:
  - k is chosen on the validation set,
  - the decision threshold is tuned on the validation set to maximize the balanced accuracy
    (otherwise k-NN would almost always answer "no" because only ~11% of clients subscribe).
The case base is the training set and it is never modified (no revise, no retain).
"""
from pathlib import Path

import numpy as np
from sklearn.neighbors import KNeighborsClassifier

from src.cbr import PROCESSED_DIR, best_threshold, evaluate  # metric helpers shared with the CBR


def load_knn_data(processed_dir=PROCESSED_DIR):
    d = np.load(Path(processed_dir) / "knn_arrays.npz")
    return {k: d[k] for k in d.files}


def run_knn(data, k_grid=(5, 11, 21, 41, 81), val_idx=None, test_idx=None, verbose=True):
    """Tune k and the threshold on validation, then predict the test clients.

    val_idx / test_idx : optional row positions, to evaluate on a subset (quick mode)."""
    Xtr, ytr = data["X_train"], data["y_train"]
    Xva, yva = data["X_val"], data["y_val"]
    Xte, yte = data["X_test"], data["y_test"]
    if val_idx is not None:
        Xva, yva = Xva[val_idx], yva[val_idx]
    if test_idx is not None:
        Xte, yte = Xte[test_idx], yte[test_idx]

    tuning, best = [], None
    for k in k_grid:
        model = KNeighborsClassifier(n_neighbors=k, weights="distance", n_jobs=-1).fit(Xtr, ytr)
        scores = model.predict_proba(Xva)[:, 1]
        t, ba = best_threshold(yva, scores)
        tuning.append({"k": k, "threshold": t, "val_balanced_accuracy": ba})
        if verbose:
            print(f"  k-NN  k={k:3d}  val balanced accuracy = {ba:.4f}  (threshold {t:.3f})")
        if best is None or ba > best["val_ba"]:
            best = {"k": k, "threshold": t, "val_ba": ba, "model": model}

    test_scores = best["model"].predict_proba(Xte)[:, 1]
    test_pred = (test_scores >= best["threshold"]).astype(int)
    return {"k": best["k"], "threshold": best["threshold"], "val_ba": best["val_ba"],
            "test_scores": test_scores, "test_pred": test_pred, "y_test": yte, "tuning": tuning}


if __name__ == "__main__":
    data = load_knn_data()
    res = run_knn(data)
    m = evaluate(res["y_test"], res["test_pred"], res["test_scores"])
    print(f"\nBest k = {res['k']}, threshold = {res['threshold']:.3f}")
    print("Test results:", {k: round(v, 4) if isinstance(v, float) else v for k, v in m.items()})
