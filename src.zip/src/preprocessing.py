"""
preprocessing.py : shared preprocessing for the Bank Marketing project (CBR + k-NN)

Reads   : data/raw/bank-additional-full.csv
Writes  : data/processed/...   (same split, two views of it)

Run from the project root:
    python preprocessing.py                  # random stratified split (default)
    python preprocessing.py --split time     # time-based split (file is chronological)

Or from a notebook:
    from preprocessing import run
    run(split="random")

What it does
  1. Loads the CSV (separator ';') and DROPS `duration` (not known before the call).
  2. Handles `pdays` (999 = never contacted): flag + days (0 when never contacted).
  3. Makes ONE split (train = case base / validation / test), fixed seed.
  4. Fits all scalers/encoders on TRAIN ONLY (no leakage), applies them to val/test.
  5. Saves two views of the same split, with identical rows and row order:
       - CBR view : numeric scaled to [0, 1], categories kept as text
       - k-NN view: standardized numeric + one-hot categories (numpy arrays)
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler

# ----------------------------------------------------------------------------
# Paths (relative to the folder that contains this script)
# ----------------------------------------------------------------------------
try:
    ROOT = Path(__file__).resolve().parent.parent
except NameError:  # running inside a notebook
    ROOT = Path.cwd()

RAW_DIR = ROOT / "data" / "raw"
PROCESSED_DIR = ROOT / "data" / "processed"
RAW_FILE = "bank-additional-full.csv"

SEED = 42
VAL_SIZE = 0.15
TEST_SIZE = 0.15


def load_raw(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Put {RAW_FILE} in {RAW_DIR} (separator ';')."
        )
    df = pd.read_csv(path, sep=";")
    df.insert(0, "row_id", np.arange(len(df)))  # original position = time order
    return df


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # 1. Leakage: call length is unknown before the call
    df = df.drop(columns=["duration"])

    # 2. Target
    df["target"] = (df["y"] == "yes").astype(int)
    df = df.drop(columns=["y"])

    # 3. pdays: 999 means "never contacted before" (not a number of days)
    never = df["pdays"].isin([999, -1])
    df["previously_contacted"] = (~never).astype(int)
    df["pdays"] = df["pdays"].where(~never, 0)

    # 4. 'unknown' stays as its own category; NaN (if any) becomes 'unknown'
    cat = [c for c in df.columns if df[c].dtype == "object" or str(df[c].dtype) in ("str", "string")]
    df[cat] = df[cat].fillna("unknown")
    return df


def make_split(df: pd.DataFrame, mode: str):
    if mode == "time":
        # File is in chronological order: oldest -> train, newest -> test
        n = len(df)
        n_test = int(n * TEST_SIZE)
        n_val = int(n * VAL_SIZE)
        train = df.iloc[: n - n_val - n_test]
        val = df.iloc[n - n_val - n_test: n - n_test]
        test = df.iloc[n - n_test:]
    else:
        train_val, test = train_test_split(
            df, test_size=TEST_SIZE, stratify=df["target"], random_state=SEED
        )
        val_frac = VAL_SIZE / (1 - TEST_SIZE)
        train, val = train_test_split(
            train_val, test_size=val_frac, stratify=train_val["target"], random_state=SEED
        )
    return train.reset_index(drop=True), val.reset_index(drop=True), test.reset_index(drop=True)


def build_views(train, val, test):
    meta_cols = ["row_id", "target"]
    feature_cols = [c for c in train.columns if c not in meta_cols]
    cat_cols = [c for c in feature_cols if train[c].dtype == "object" or str(train[c].dtype) in ("str", "string")]
    num_cols = [c for c in feature_cols if c not in cat_cols]
    # previously_contacted is a 0/1 flag: treat it as numeric (already in [0, 1])

    # ---------------- CBR view: min-max scaling fitted on TRAIN ----------------
    mins = train[num_cols].min()
    maxs = train[num_cols].max()
    rng = (maxs - mins).replace(0, 1)

    def cbr_view(d):
        out = d[meta_cols].copy()
        scaled = ((d[num_cols] - mins) / rng).clip(0, 1)  # clip: val/test may exceed train range
        out = pd.concat([out, scaled, d[cat_cols]], axis=1)
        return out

    cbr = {"train": cbr_view(train), "val": cbr_view(val), "test": cbr_view(test)}

    # ---------------- k-NN view: standardize + one-hot, fitted on TRAIN ----------------
    scaler = StandardScaler().fit(train[num_cols])
    try:
        ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:  # older scikit-learn
        ohe = OneHotEncoder(handle_unknown="ignore", sparse=False)
    ohe.fit(train[cat_cols])

    def knn_view(d):
        return np.hstack([scaler.transform(d[num_cols]), ohe.transform(d[cat_cols])])

    feature_names = list(num_cols) + list(ohe.get_feature_names_out(cat_cols))
    knn = {k: knn_view(d) for k, d in zip(["train", "val", "test"], [train, val, test])}

    meta = {
        "numeric_cols": num_cols,
        "categorical_cols": cat_cols,
        "numeric_min": mins.to_dict(),
        "numeric_max": maxs.to_dict(),
        "knn_feature_names": feature_names,
        "seed": SEED,
    }
    return cbr, knn, meta


def save(cbr, knn, ytr, meta, mode, raw_clean):
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

    for name, d in cbr.items():
        d.to_csv(PROCESSED_DIR / f"cbr_{name}.csv", index=False)

    np.savez_compressed(
        PROCESSED_DIR / "knn_arrays.npz",
        X_train=knn["train"], y_train=ytr["train"],
        X_val=knn["val"], y_val=ytr["val"],
        X_test=knn["test"], y_test=ytr["test"],
        row_id_train=cbr["train"]["row_id"].values,
        row_id_val=cbr["val"]["row_id"].values,
        row_id_test=cbr["test"]["row_id"].values,
    )

    meta["split_mode"] = mode
    meta["sizes"] = {k: int(len(v)) for k, v in cbr.items()}
    with open(PROCESSED_DIR / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)


def sanity_checks(cbr, knn, ytr):
    print("\n=== Sanity checks ===")
    for k in ["train", "val", "test"]:
        n = len(cbr[k])
        rate = cbr[k]["target"].mean()
        print(f"{k:5s}: {n:6d} rows | positive rate = {rate:.3%} | kNN matrix = {knn[k].shape}")
        assert knn[k].shape[0] == n, "row mismatch between views"
        assert (cbr[k]["target"].values == ytr[k]).all(), "target mismatch between views"
        assert not np.isnan(knn[k]).any(), "NaN in kNN matrix"
    ids = [set(cbr[k]["row_id"]) for k in ["train", "val", "test"]]
    assert not (ids[0] & ids[1]) and not (ids[0] & ids[2]) and not (ids[1] & ids[2]), "overlap between splits"
    print("OK: no overlap between splits, views are aligned, no NaN.")


def run(split: str = "random"):  # split = "random" or "time"
    raw_path = RAW_DIR / RAW_FILE
    print(f"Reading  : {raw_path}")
    df = clean(load_raw(raw_path))
    print(f"Cleaned  : {df.shape[0]} rows, {df.shape[1] - 2} features (duration removed)")

    train, val, test = make_split(df, split)

    cbr, knn, meta = build_views(train, val, test)
    ytr = {"train": train["target"].values, "val": val["target"].values, "test": test["target"].values}

    save(cbr, knn, ytr, meta, split, df)
    sanity_checks(cbr, knn, ytr)
    print(f"\nSaved in : {PROCESSED_DIR}")
    return cbr, knn, meta


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", choices=["random", "time"], default="random")
    args = ap.parse_args()
    run(args.split)
